package project2;
// simple class that extends node
public class Num extends Node {
	public Num (char e) {
		element = e;
		l = null;
		r=null;
	}

public String toString() {
return "" + element;	
}
}
