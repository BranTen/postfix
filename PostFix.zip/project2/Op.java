package project2;

/*
 * normal operator class. holds an operator.
 */

public class Op extends Node {

	public Op (char e) {

		element = e;
		l = null;
		r = null;
	}

	public String toString() { // i chose to have the to string display more information on the operator specific class
								// because since the operator is the root of the numbers it should properly display
		return "(" + l + " " + element + " " + r + ")";
	}
}
