package project2;
/*
 * this class is where the work is being done to evaluate the postfix expression
 */
import javax.swing.JOptionPane;
//this class is meant to take in a string value from the gui and seperates it into two seperate stacks



public class PostfixExpression {
	Node root; // create a root node
	boolean add = false; // this will be for the binary tree 
	public PostfixExpression(String n) {

		for ( int i = n.length() -1; i >= 0; i--) {// use a decending for loop in order to evaluate postfix
			add = false; // nothing added (new element)
			root = addNode (root, n.charAt(i));// continue to add nodes as long as there are still elements in the string
			
		}

	}


	private Node addNode(Node n, char e) {

		if(n != null) {
			if(n instanceof Op) { // if it is operator 
				if(n.r == null || n.r instanceof Op) {// if the right node is null or if the right node is an operator
					n.r = addNode(n.r, e);//add node
				}
			if(n instanceof Num) { // same for numbers
				if(n.l == null || n.l instanceof Num){
					n.l = addNode(n.l, e);
				}
			}
           if(!add&&n.l==null||n.l instanceof Op)
           {
                  n.l=addNode(n.l, e);
           }

			}
		}else {
			add = true;
			if(precedence(e)) { // this checks for if the element is an operator and if it is add it as an operator
				return new Op(e);
			}else {
				if(!precedence(e)) { // if not then add it to numbers
					//System.out.print(e);

					return new Num(e);
				}
			}
		}
		
		return n;// once the element has been added, the program will move on to next
	}


	private boolean precedence(char c) {
	
		if ((c == '*' || c == '/' || c == '+' || c == '-')) { // simply checks for operators
			
			return true;
		} else { // simply checks for nubers
			
			if(c <= '9' && c >='0' ) {
			return false;
			}// simply you should not have put that charecter in there because it dont make sence
			else {
			JOptionPane.showMessageDialog( null, "incorrect charecter","user error", JOptionPane.ERROR_MESSAGE);
			}
			return false;
		}
	}

	public String toString() {
		return root.toString(); // this is where the root goes and collects all of the elements and displays them as a regular equation
	}

	}

