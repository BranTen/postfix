package project2;

import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;

import javax.swing.*;
import java.awt.GridLayout;
import javax.swing.JFrame;
 // this class makes up the interface while handling the button
public class Interface extends JFrame implements ActionListener {

	JFrame frame = new JFrame(); 
	
	//labels
	 JLabel enterPfixLab = new JLabel("Enter Postfix Expression: ");
	 JLabel	resultLab = new JLabel("Infix Expression: ");

	//textfields
	 JTextField enterPfix = new JTextField(16);
	 JTextField	result = new JTextField(16);

	//the button
	 JButton evaluate = new JButton("Construct Tree");

public Interface () { 
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	frame.setLayout(getLayout());
	Panel p1 = new Panel();
	Panel p2 = new Panel();
	Panel p3 = new Panel();
	Panel p4 = new Panel();

	frame.setSize(400, 150);

// add the elements
	p1.add(enterPfixLab);
	p1.add(enterPfix);
	
	p2.add(evaluate);
	
	p3.add(resultLab);
	p3.add(result);
	
	p4.add(p1);
	p4.add(p2);
	p4.add(p3);

	frame.add(p4);


	frame.setTitle("Three Adddress Generator");
	frame.setVisible(true);

	evaluate.addActionListener(this); // makes the button do something

}

@Override
// this method takes the text from the textfield and sends it over to thepostfixexpression class to be evaluated
public void actionPerformed(ActionEvent event) {
	
	String n = enterPfix.getText();
	PostfixExpression p = new PostfixExpression(n);
		result.setText(String.valueOf(p.toString())); // after it is evaluated it displays the answer on the other textfield

}
}
