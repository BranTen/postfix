package project2;
/*
 * this class is a node class with left & right nodes like a binary tree
 */
public abstract class Node {
	
 char element;
 Node l;
 Node r;
 

 
public char getElement() {
	return element;
}

public void setElement(char e) {
element = e;
}

}
